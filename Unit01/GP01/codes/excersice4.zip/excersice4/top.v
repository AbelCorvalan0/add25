module top(
    output signed [15:0] y_out,

    input signed  [7:0]   x_in,
    input                  clk,
    input                rst_n
);

    // Define wires.
    wire signed [7:0]  term1_x;
    wire signed [15:0] term2_x;
    wire signed [15:0] term3_x;
    wire signed [15:0] term4_x;

    wire signed [15:0] term1_y;
    wire signed [15:0] term2_y;

    wire signed [15:0] sum_term;
    wire signed [15:0] y_out_wire;

    // Assign inputs to the wires.
    assign term1_x = x_in;
    assign term2_x = x_in; 
    assign term3_x = x_in;
    assign term4_x = x_in;

    // Instanciación de módulos para términos de entrada
    term1 u_term1(
        .y(term1_x),    // x[n] - pasa directamente
        .x(x_in),
        .clk(clk)
    );
    
    term2 u_term2(
        .y(term2_x),    // -x[n-1]
        .x(x_in),
        .clk(clk),
        .rst_n(rst_n)
    );
    
    term3 u_term3(
        .y(term3_x),    // x[n-2]
        .x(x_in),
        .clk(clk),
        .rst_n(rst_n)
    );
    
    term4 u_term4(
        .y(term4_x),    // x[n-3]
        .x(x_in),
        .clk(clk),
        .rst_n(rst_n)
    );
    
    // Instanciación de módulos para términos de retroalimentación
    term5 u_term5(
        .y(term1_y),    // 0.5*y[n-1]
        .clk(clk),
        .rst_n(rst_n),
        .y_in(y_out_wire)
    );
    
    term6 u_term6(
        .y(term2_y),    // 0.25*y[n-2]
        .clk(clk),
        .rst_n(rst_n),
        .y_in(y_out_wire)
    );

    // Convertir term1_x (8 bits) a 16 bits con extensión de signo
    wire signed [15:0] term1_x_extended = { {8{term1_x[7]}}, term1_x };
    
    // Suma de todos los términos según la ecuación:
    // y[n] = x[n] - x[n-1] + x[n-2] + x[n-3] + 0.5*y[n-1] + 0.25*y[n-2]
    assign sum_term = term1_x_extended + term2_x + term3_x + term4_x + 
                     term1_y + term2_y;
    
    // Registro de salida
    reg signed [15:0] y_reg;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            y_reg <= 16'b0;
        end else begin
            y_reg <= sum_term;
        end
    end
    
    // Asignar salidas
    assign y_out      = y_reg;
    assign y_out_wire = y_reg;

endmodule