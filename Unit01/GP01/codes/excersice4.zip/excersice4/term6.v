// 0.25 y[n-2]
module term6(
    output signed [15:0] y,      // CHANGED: removed 'reg'
    input signed [15:0] y_in,    // CHANGED: added signed
    input clk,
    input rst_n
);

reg signed [15:0] y_reg1, y_reg2;  // CHANGED: [31:0] to [15:0]

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n) begin
        y_reg1 <= 0;
        y_reg2 <= 0;
    end 
    else begin
        y_reg1 <= y_in;
        y_reg2 <= y_reg1;
    end
end

// 0.25*y[n-2] = y[n-2] >> 2
assign y = y_reg2 >>> 2;

endmodule