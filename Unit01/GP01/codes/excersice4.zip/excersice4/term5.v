// 0.5 y[n-1]
module term5(
    output signed [15:0] y,      // CHANGED: removed 'reg'
    input clk,
    input rst_n,
    input signed [15:0] y_in     // CHANGED: using input signal
);

reg signed [15:0] y_reg;  // CHANGED: [31:0] to [15:0]

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        y_reg <= 0;
    else
        y_reg <= y_in;           // CHANGED: y -> y_in
end

// 0.5*y[n-1] = y[n-1] >> 1
assign y = y_reg >>> 1;

endmodule