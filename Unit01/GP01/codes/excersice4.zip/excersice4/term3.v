module term3(
    output signed [15:0] y,
    input signed [7:0] x,
    input rst_n,
    input clk
);

reg signed [7:0] x1, x2;

always @(posedge clk or negedge rst_n)
    if(!rst_n) begin
        x1 <= 0;
        x2 <= 0;
    end
    else begin
        x1 <= x;
        x2 <= x1; 
    end

// Sign extend from 8 to 16 bits
assign y = {{8{x2[7]}}, x2};

endmodule