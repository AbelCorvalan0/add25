`timescale 1ns/1ps  

module tb_top;

    // Define parameters.
    localparam CLK_PERIOD= 10; // 10ns = 100MHz.

    // Define all inputs and outputs
    // of this top module.
    reg signed [7:0]     x_in;
    reg                   clk;
    reg                 rst_n;

    // Module Output.
    wire signed [15:0]  y_out;

    // Create connections.
    top uut (
        .y_out (y_out),
        .x_in  (x_in) ,
        .clk   (clk)  ,
        .rst_n (rst_n)
    );

    initial begin
        clk = 0;
        forever begin
            #(CLK_PERIOD/2) clk = ~clk;
        end
    end

    // Reset and Stimulus.
    initial begin
        // Initialize Inputs
        x_in = 0;
        rst_n = 0;

        // Apply Reset
        #20;
        rst_n = 1;

        // Test Case 1: Simple step input
        x_in = 10;
        #40;

        // Test Case 2: Negative input
        x_in = -20;
        #40;

        // Test Case 3: Zero input
        x_in = 0;
        #40;

        // Test Case 4: Ramp-like sequence
        x_in = 1;   #10;
        x_in = 2;   #10;
        x_in = 3;   #10;
        x_in = 4;   #10;
        x_in = 5;   #10;
        x_in = 0;   #30;

        // End simulation
        $display("Simulation finished.");
        $finish;
    end

    // Monitor to display signals
    initial begin
        $monitor("Time = %t, x_in = %d, y_out = %d", $time, x_in, y_out);
    end

    // Optional: Generate waveform file for Vivado
    initial begin
        $dumpfile("tb_top.vcd");
        $dumpvars(0, tb_top);
    end   

endmodule