module term2(
    output signed [15:0] y,
    input signed [7:0] x,
    input clk,
    input rst_n
);

reg signed [7:0] x1;    // x[n-1] stays as 8-bit

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        x1 <= 0;
    else 
        x1 <= x;
end

// Sign extend from 8 to 16 bits before negation
assign y = -{{8{x1[7]}}, x1};

endmodule