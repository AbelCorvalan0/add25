module term1(
    output reg signed [7:0] y,      // Changed to reg
    input signed [7:0] x,
    input clk,
    input rst_n                     // ADDED: Missing reset
);

always @(posedge clk or negedge rst_n)  // Added reset sensitivity
begin
    if(!rst_n)
        y <= 0;                        // Use non-blocking
    else
        y <= x;
end

endmodule